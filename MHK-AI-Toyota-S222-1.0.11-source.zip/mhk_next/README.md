# MHK AI (Toyota bZ3X adaptation)

# MHK AI

MHK AI is a branded Android voice-assistant launcher and offline wake-word utility for compatible Android head units. The launcher name is **MHK AI**. The application ID and Kotlin namespace are `com.mhk.ai.assistant`; all application source packages have been migrated to this MHK AI namespace.

## Current adaptation status

- App display name and user-facing update/service notifications are branded MHK AI.
- Version set to `1.0.11` / version code `11`.
- OTA release lookup points to `mohamedhanfi1981-afk/Assistant` so it does not silently pull releases from the upstream author's repository.
- Assistant launching now tries the selected app directly first and falls back to Android's standard `ACTION_ASSIST`. It no longer sends the ADB `KEYCODE_ASSIST` command before every launch, which could invoke the vehicle's native assistant instead of the selected app.
- Wake-word model import now copies to a temporary file, validates that copied ONNX model, and only then installs it.

## Toyota bZ3X / Android 11 notes

Toyota bZ3X S222 compatibility is not guaranteed by source inspection alone. Test on the actual Android 11 head unit for microphone input, foreground microphone service lifetime, battery optimization behavior, assistant intent availability, and accessibility key-event delivery. This fork uses standard Android battery-optimization settings and contains no BYD/DiLink auto-start integration.

The bundled wake-word models are `Alice`, `hey_billy`, `ok_boss`, `ok_jarvis`, and `wall-e`. **An Arabic “يا MHK” model has not been trained or included.** The current source does not contain a working custom-training pipeline for its OpenWakeWord ONNX models. A genuine model must be trained with a compatible OpenWakeWord training workflow and validated on Arabic recordings before it can be added; relabeling an existing model would not make it recognize “يا MHK”.

The app uses the new application ID `com.mhk.ai.assistant` and retains the original `arm64-v8a` ABI filter. Because the application ID changed, Android treats this as a separate app; it will not update an older installation under the previous package name. It does not change Toyota vehicle settings or flash the head unit.

## Build a debug APK with GitHub Actions

1. Push this project to the `main` branch of the intended GitHub repository (or use the Actions workflow dispatch).
2. Open **Actions → Build MHK AI Debug APK → Run workflow**.
3. Download the `MHK-AI-Toyota-S222-debug-apk` artifact from the completed run.
4. Install and test on the vehicle only after confirming the APK was produced successfully.

A locally built debug APK is signed with a debug key. It cannot update an already-installed APK signed with a different key; uninstalling the old app may erase its settings.

---


![Stars](https://img.shields.io/github/stars/kangrio/Assistant) ![Forks](https://img.shields.io/github/forks/kangrio/Assistant) ![Downloads](https://img.shields.io/github/downloads/kangrio/Assistant/total) ![Release](https://img.shields.io/github/v/release/kangrio/Assistant)

![Open Issues](https://img.shields.io/github/issues-raw/kangrio/Assistant) ![Closed Issues](https://img.shields.io/github/issues-closed-raw/kangrio/Assistant) ![License](https://img.shields.io/github/license/kangrio/Assistant) 


**MHK AI** (`com.mhk.ai.assistant`, legacy application ID) is an Android voice interaction bridge for compatible Android head units / AOSP devices.

Launcher shortcuts directly to your preferred AI voice assistant (Google Assistant, ChatGPT, Perplexity, Claude, etc.), provides **always-listening offline hotword / wake-word detection** ("Hey Rio", "Alexa", "Snowboy", or custom trained models), and includes a modern onboarding wizard to configure system-level voice interaction services with ease.

---

## Key Features

- **One-Tap Voice Launcher**:
  - Launching the app via home launcher icon, steering wheel button, or widget immediately invokes your selected voice assistant without opening configuration screens once set up.
  - Custom launch profiles:
    - **Google App / Google Assistant**: Executes `android.intent.action.VOICE_COMMAND`.
    - **ChatGPT**: Direct intent target to ChatGPT's voice assistant mode (`com.openai.voice.assistant.AssistantActivity`).
    - **Other AI / Voice Interaction Services**: Dispatches standard `Intent.ACTION_ASSIST`.
  - Optional audible start chime ("ding") confirmation sound upon activation.

- **Offline Hotword & Wake-Word Detection (`VoiceWakeService`)**:
  - Continuous, low-latency wake-word detection powered by embedded Snowboy engine.
  - Ships with bundled offline models: **Hey Rio** (`hey_rio.pmdl`), **Alexa** (`alexa.pmdl`), and **Snowboy** (`snowboy.pmdl`).
  - Configurable microphone input gain and detection sensitivity sliders.
  - Runs efficiently as a foreground service with a persistent notification and quick-access settings.

- **In-App Custom Wake-Word Trainer**:
  - Built-in training studio powered by Snowboy Seasalt API.
  - Record voice samples directly on the head unit / device (minimum 3 samples).
  - Train custom `.pmdl` wake-word models on the fly.

- **Guided Jetpack Compose Onboarding Wizard (`PermissionOnboardingActivity`)**:
  - Interactive status check and setup workflow for all required capabilities:
    1. **Microphone Access**: Grants audio capture for hotword detection.
    2. **Display Over Other Apps**: Allows launching the assistant UI seamlessly over active apps (e.g. navigation / media).
    3. **Background & Battery Management**: Standard Android battery-optimization exemption flow; no vehicle-manufacturer-specific auto-start intent.
    4. **Write Secure Settings**: Automatic on-device grant via local ADB socket (`dadb`) or manual ADB command copy.
    5. **Target AI Assistant Selection**: Scans installed `VoiceInteractionService` providers and allows 1-tap switching.
    6. **Notification Permission**: Enables background status indication (Android 13+).

- **Boot Persistence**:
  - `BootReceiver` captures `BOOT_COMPLETED` to re-apply `Settings.Secure` assistant keys and initialize the voice wake service on startup.

---

## Architecture & Flow

```
                             +---------------------------+
                             |   User Launches App       |
                             |   or Wake Word Detected   |
                             +-------------+-------------+
                                           |
                                           v
                             +---------------------------+
                             |       StartActivity       |
                             +-------------+-------------+
                                           |
                               Is Setup Fully Completed?
                      (Secure Settings, Audio, Assistant App,
                         Auto-Start, Overlay Permissions)
                                    /             \
                                  YES              NO
                                  /                 \
                                 v                   v
             +-----------------------+   +--------------------------------+
             | Trigger Voice Command |   | PermissionOnboardingActivity   |
             |  - Google Assistant   |   |   (Setup Wizard)    |
             |  - ChatGPT Voice      |   +--------------------------------+
             |  - Custom Assist App  |
             +-----------------------+
```

---

## Secure Settings

To designate the default voice interaction provider system-wide, the app configures the following `Settings.Secure` keys:

| Key | Description / Example Value |
| :--- | :--- |
| `assistant` | Flattened component name (e.g., `com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService`) |
| `voice_interaction_service` | Flattened component name (e.g., `com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService`) |

---

## Setup & Permissions

### Granting `WRITE_SECURE_SETTINGS`

Modifying system assistant keys requires the `android.permission.WRITE_SECURE_SETTINGS` permission.

#### Method 1: Automatic In-App Grant (Local ADB)
1. Open the app onboarding screen.
2. Under **Write Secure Settings**, tap **Grant via Local ADB**.
3. The app connects to the local ADB daemon via `dadb` and grants the permission automatically without needing a computer.

#### Method 2: Manual ADB Command
If local ADB discovery is unavailable, execute the following command via PC or Wireless ADB:

```bash
adb shell pm grant com.mhk.ai.assistant android.permission.WRITE_SECURE_SETTINGS
```

---

## Project Structure

```
Assistant/
├── app/
│   ├── build.gradle.kts
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── assets/
│           │   └── snowboy/              # Pretrained models (.pmdl) & resources
│           │       ├── common.res
│           │       └── models/
│           │           ├── alexa.pmdl
│           │           ├── hey_rio.pmdl
│           │           └── snowboy.pmdl
│           ├── java/com/kangrio/byd/assistant/
│           │   ├── App.kt                # Application entry point
│           │   ├── Constant.kt           # Shared constants & preference keys
│           │   ├── StartActivity.kt      # Fast launcher & voice intent dispatcher
│           │   ├── activity/
│           │   │   ├── PermissionOnboardingActivity.kt # Guided onboarding host
│           │   │   └── SettingsActivity.kt             # Hotword settings & voice trainer
│           │   ├── data/
│           │   │   └── AssistantApp.kt   # Assistant metadata model
│           │   ├── receiver/
│           │   │   └── BootReceiver.kt   # Restores settings & service on boot
│           │   ├── service/
│           │   │   ├── SnowboyDetector.kt# Audio recorder & Snowboy JNI bridge
│           │   │   └── VoiceWakeService.kt # Foreground service for wake word
│           │   ├── ui/
│           │   │   ├── composable/       # Shared UI components & app icons
│           │   │   ├── onboarding/       # Onboarding wizard screens & permission cards
│           │   │   └── theme/            # Material 3 theme & typography
│           │   └── util/
│           │       ├── Preferences.kt    # SharedPreferences wrapper
│           │       ├── SnowboyTrainClient.kt # API client for custom model training
│           │       └── Utils.kt          # System helpers, dadb runner & intent utilities
│           └── res/
│               └── raw/
│                   └── ding.mp3          # Activation chime
├── build.gradle.kts
└── settings.gradle.kts
```

---

## Building from Source

### Requirements
- Android Studio
- Android SDK (API 37 compile target, `minSdk` 24)
- Supported ABIs: `armeabi-v7a`, `arm64-v8a`, `x86_64`

### Build Commands

```bash
# Build Debug APK
./gradlew assembleDebug

# Build Release APK
./gradlew assembleRelease

# Build Beta Variant
./gradlew assembleBeta
```

Artifacts will be generated in `app/build/outputs/apk/<variant>/` following the naming format:
`Assistant-<versionName>(<versionCode>)-<variant>-<timestamp>.apk`

---

## Permissions Overview

| Permission                                             | Purpose                                                                        |
|:-------------------------------------------------------|:-------------------------------------------------------------------------------|
| `RECORD_AUDIO`                                         | Required for wake-word listening and voice sample recording.                   |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_MICROPHONE` | Keeps the hotword detector running reliably in the background.                 |
| `SYSTEM_ALERT_WINDOW`                                  | Enables launching assistant interfaces over active apps.                       |
| `WRITE_SECURE_SETTINGS`                                | Configures system default assistant and voice interaction services.            |
| `RECEIVE_BOOT_COMPLETED`                               | Automatically restarts hotword service and secures settings on device boot.    |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`                 | Prevents Android OS from killing background services in standby.               |
| `POST_NOTIFICATIONS`                                   | Displays the foreground service notification on Android 13+.                   |
| `INTERNET`                                             | Used for local ADB loopback socket communication and wake-word model training. |

---

## Credits

This project builds upon the following open-source libraries and projects:

| Project                                                                                 | Author / Org | Description                                                                                                                                                                      |
|:----------------------------------------------------------------------------------------|:-------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [AndroidWakeWord](https://github.com/Suxsem/AndroidWakeWord)                            | Suxsem       | Android library implementing openWakeWord detection using ONNX Runtime and SpeexDSP.                                                                                             |
| [dadb](https://github.com/mobile-dev-inc/dadb)                                          | mobile.dev   | A Kotlin library for communicating with Android devices over ADB directly from the device itself. Used here to automatically grant `WRITE_SECURE_SETTINGS` without needing a PC. |
| [wakewords-collection](https://github.com/fwartner/home-assistant-wakewords-collection) | fwartner     | Community Collection of Wake-Words for Home Assistant                                                                                                                            |


---

## License

Distributed under the [MIT License](LICENSE).
