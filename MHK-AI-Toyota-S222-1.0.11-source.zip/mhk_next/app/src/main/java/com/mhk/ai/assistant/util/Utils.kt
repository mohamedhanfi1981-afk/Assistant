package com.mhk.ai.assistant.util

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.SoundPool
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.service.voice.VoiceInteractionService
import android.util.Log
import android.widget.Toast
import dadb.Dadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration.Companion.milliseconds
import androidx.core.content.edit
import androidx.core.net.toUri
import com.mhk.ai.assistant.Constant
import com.mhk.ai.assistant.R
import com.mhk.ai.assistant.StartActivity
import com.mhk.ai.assistant.data.AssistantApp
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

object Utils {
    val scope = MainScope()
    private val soundPool = SoundPool.Builder()
        .setMaxStreams(1)
        .build()

    private var dingSound: Int = -1

    /**
     * Check if a permission is granted.
     */
    fun isGranted(context: Context, permission: String): Boolean {
        return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Set default voice assistant app to be used.
     */
    fun enableVoiceAssistant(context: Context, componentName: String? = null) {
        val componentName = componentName ?: return

        putSecureSetting(context, "assistant", null)
        putSecureSetting(context, "voice_interaction_service", null)
        Thread.sleep(100)
        putSecureSetting(context, "assistant", componentName)
        putSecureSetting(context, "voice_interaction_service", componentName)
    }

    /**
     * List all installed voice assistant apps with support for VoiceInteractionService.
     */
    fun listAssistantPackages(context: Context): List<AssistantApp> {
        val pm = context.packageManager

        return pm.queryIntentServices(
            Intent(VoiceInteractionService.SERVICE_INTERFACE),
            0
        ).mapNotNull { resolveInfo ->
            val serviceInfo = resolveInfo.serviceInfo ?: return@mapNotNull null

            AssistantApp(
                name = serviceInfo.loadLabel(pm).toString(),
                packageName = serviceInfo.packageName,
                className = serviceInfo.name,
            )
        }
    }

    /**
     * Check if a package has support for VoiceInteractionService.
     */
    fun isSupportAssistService(context: Context, packageName: String): Boolean {
        val pm = context.packageManager
        val intent = Intent(VoiceInteractionService.SERVICE_INTERFACE)
        intent.setPackage(packageName)
        return pm.queryIntentServices(intent, 0).isNotEmpty()
    }

    /**
     * Get the currently selected voice assistant app.
     */
    fun getCurrentAssistantApp(context: Context): AssistantApp {
        val assistant = Settings.Secure.getString(context.contentResolver, "assistant") ?: return AssistantApp()

        val component = ComponentName.unflattenFromString(assistant) ?: return AssistantApp()
        val appInfo = context.packageManager.getPackageInfo(component.packageName, 0)
        val appLabel = appInfo.applicationInfo?.loadLabel(context.packageManager)?.toString()

        val assistantApp = AssistantApp(
            name = appLabel ?: "",
            packageName = component.packageName,
            className = component.className,
        )

        return assistantApp
    }

    /**
     * Check if voice assistant is enabled.
     */
    fun isEnabledVoiceAssistant(context: Context): Boolean {
        val assistant = Settings.Secure.getString(context.contentResolver, "assistant")
        val voiceInteractionService =
            Settings.Secure.getString(context.contentResolver, "voice_interaction_service")

        return !assistant.isNullOrEmpty() && !voiceInteractionService.isNullOrEmpty()
    }

    /**
     * Check if all required permissions are granted.
     */
    fun setupCompleted(context: Context): Boolean {
        // Selecting the system voice interaction provider requires this privileged grant.
        val isGrantedWriteSecureSettings = isGranted(context, Manifest.permission.WRITE_SECURE_SETTINGS)
        val isEnableVoiceAssistant = isEnabledVoiceAssistant(context)
        val isAssistantAppsInstalled = listAssistantPackages(context).isNotEmpty()
        val isAutoStart = isGrantedAutoStart(context)
        return isGrantedWriteSecureSettings && isEnableVoiceAssistant && isAssistantAppsInstalled && isAutoStart
    }

    /**
     * Play a ding sound when Voice Assistant app is launched.
     */
    private fun playDing(context: Context, delayMs: Long = 0) {
        if (!Preferences.playDingOnStart) return

        if (dingSound == -1) {
            dingSound = soundPool.load(context, R.raw.ding, 1)
            soundPool.setOnLoadCompleteListener { pool, i, i1 ->
                scope.launch {
                    delay(delayMs.milliseconds)
                    soundPool.play(dingSound, 1f, 1f, 0, 0, 1f)
                }
            }
        } else {
            scope.launch {
                delay(delayMs.milliseconds)
                soundPool.play(dingSound, 1f, 1f, 0, 0, 1f)
            }
        }
    }

    /**
     * Launch the currently selected voice assistant app.
     */
    fun startVoiceAssistant(context: Context) = MainScope().launch {
        // Services and receivers must enter through the launcher activity so Android
        // can present the selected assistant from a foreground UI context.
        if (context !is Activity) {
            try {
                context.startActivity(
                    Intent(context, StartActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                )
            } catch (e: Throwable) {
                Log.e("Utils", "Unable to open MHK AI launcher", e)
            }
            return@launch
        }

        val selected = getCurrentAssistantApp(context)
        val packageName = selected.packageName

        // Prefer a direct app intent. Do not send KEYCODE_ASSIST first: on a head unit
        // that key may open the vehicle's native assistant instead of the user's choice.
        try {
            val intent = when (packageName) {
                Constant.GOOGLE_APP_PACKAGE -> Intent(Intent.ACTION_VOICE_COMMAND).apply {
                    setPackage(Constant.GOOGLE_APP_PACKAGE)
                }
                Constant.CHATGPT_APP_PACKAGE -> Intent().apply {
                    component = ComponentName(
                        Constant.CHATGPT_APP_PACKAGE,
                        Constant.CHATGPT_APP_ASSISTANT_CLASS_NAME
                    )
                    putExtra("isAssistant", true)
                }
                else -> Intent(Intent.ACTION_ASSIST).apply {
                    if (packageName.isNotEmpty()) setPackage(packageName)
                }
            }
            context.startActivity(intent)
            playDing(context, delayMs = 1000)
            return@launch
        } catch (e: Throwable) {
            Log.w("Utils", "Selected assistant could not be opened directly; trying system assist", e)
        }

        // Last-resort Android standard assistant intent. This does not alter secure settings.
        try {
            context.startActivity(Intent(Intent.ACTION_ASSIST))
            playDing(context, delayMs = 1000)
        } catch (e: Throwable) {
            Log.e("Utils", "No compatible voice assistant activity is available", e)
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "تعذر فتح المساعد الصوتي. راجع اختيار التطبيق وصلاحياته.", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun startVoiceAssistantViaAdb() {
        ShellServer.exec("input keyevent 219")
    }

    /**
     * Get the Notification Listener component name for a given package name.
     */
    fun getNotificationListenerComponentName(context: Context, packageName: String): ComponentName? {
        val intent = Intent("android.service.notification.NotificationListenerService").apply {
            setPackage(packageName)
        }
        val resolveInfos = context.packageManager.queryIntentServices(intent, 0)
        if (resolveInfos.isEmpty()) return null
        val serviceInfo = resolveInfos[0].serviceInfo
        return ComponentName(serviceInfo.packageName, serviceInfo.name)
    }

    /**
     * Check if the Notification Listener service is enabled for a given package name.
     */
    fun isNotificationListenerEnabled(context: Context, packageName: String): Boolean {
        val notificationListeners = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        val components = notificationListeners?.split(":") ?: emptyList()
        return components.any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    /**
     * Grant the Notification Listener service permission for a given package name via ADB.
     */
    suspend fun grantNotificationListener(context: Context, packageName: String): Boolean =
        withContext(Dispatchers.IO) {
            if (!isGranted(context, Manifest.permission.WRITE_SECURE_SETTINGS)) return@withContext false

            val componentName =
                getNotificationListenerComponentName(context, packageName)?.flattenToString()
                    ?: return@withContext false

            adbShell(context, "cmd notification allow_listener $componentName")
            return@withContext isNotificationListenerEnabled(context, packageName)
        }

    /**
     * Put a secure setting.
     */
    private fun putSecureSetting(context: Context, key: String, value: String?) {
        if (!isGranted(context, Manifest.permission.WRITE_SECURE_SETTINGS)) return

        Settings.Secure.putString(context.contentResolver, key, value)
    }

    /**
     * Run a shell command via ADB.
     */
    suspend fun adbShell(context: Context, cmd: String) =
        withContext(Dispatchers.IO) {
            setupUserHome(context)
            val result = withTimeoutOrNull(20_000L.milliseconds) {
                while (isActive) {
                    try {
                        var dAdb = Dadb.discover(connectTimeout = 2000, socketTimeout = 5000)
                        dAdb?.shell("echo 'init'") ?: throw Throwable("fail to connect adb")
                        dAdb.close()

                        dAdb = Dadb.discover(connectTimeout = 2000, socketTimeout = 5000)
                        dAdb?.shell(cmd)
                        dAdb?.close()
                        return@withTimeoutOrNull true
                    } catch (e: Throwable) {
                        delay(100L.milliseconds)
                    }
                }
                false
            }

            if (result != true) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "ADB connection failed. Please check ADB and try again.", Toast.LENGTH_SHORT).show()
                }
            }
        }

    /**
     * Request a permission via ADB.
     */
    suspend fun adbRequestPermission(context: Context, permission: String) =
        withContext(Dispatchers.IO) {
            setupUserHome(context)
            adbShell(context, "pm grant ${context.packageName} $permission")
        }

    /**
     * setup user home when it is empty required by DAdb library.
     */
    private fun setupUserHome(context: Context) {
        val userHome = System.getProperty("user.home") ?: ""
        if (userHome.isEmpty()) {
            val userDir = context.filesDir.absolutePath
            System.setProperty("user.home", userDir)
        }
    }

    /**
     * Open the Google Play Store to install the app.
     */
    fun openStore(context: Context) {
        try {
            val intent = Intent(
                Intent.ACTION_VIEW,
                "market://".toUri()
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Throwable) {
            val intent = Intent(
                Intent.ACTION_VIEW,
                "https://play.google.com".toUri()
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    /**
     * Check whether Android battery optimization is disabled for this app.
     * Vehicle-specific auto-start APIs are intentionally not used.
     */
    fun isGrantedAutoStart(context: Context): Boolean {
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            power.isIgnoringBatteryOptimizations(context.packageName)
    }

    /**
     * Open Android's standard battery-optimization exemption screen.
     */
    @SuppressLint("BatteryLife")
    fun openAutoStartSettings(context: Context) = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = "package:${context.packageName}".toUri()
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } else {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    /**
     * Mark the last auto-start update time.
     */
    fun markAutoStartTime(context: Context) {
        val prefs = context.getSharedPreferences(context.packageName, Context.MODE_PRIVATE)
        prefs.edit {
            putLong(
                "last_update_time",
                System.currentTimeMillis()
            )
        }
    }

    /**
     * Format byte count into human-readable size string.
     */
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
        val formatted = String.format(java.util.Locale.US, "%.1f", bytes / Math.pow(1024.0, digitGroups.toDouble()))
        return "$formatted ${units[digitGroups]}"
    }
}