package com.mhk.ai.assistant.data

data class AssistantApp(
    val name: String = "",
    val packageName: String = "",
    val className: String = "",
    val componentName: String = "$packageName/$className"
)
