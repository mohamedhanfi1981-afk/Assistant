package com.mhk.ai.assistant.activity

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.mhk.ai.assistant.ui.onboarding.PermissionOnboardingScreen
import com.mhk.ai.assistant.ui.theme.AssistantTheme
import com.mhk.ai.assistant.util.Utils

class PermissionOnboardingActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AssistantTheme {
                PermissionOnboardingScreen(
                    onOnboardingFinished = {
                        finishOnboarding()
                    }
                )
            }
        }
    }

    private fun finishOnboarding() {
        startActivity(Intent(this, SettingsActivity::class.java))
        finish()
    }
}
